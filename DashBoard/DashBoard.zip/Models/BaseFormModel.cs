﻿namespace DashBoard.Models
{
    public class BaseFormModel
    {
        public string Id { get; set; }
        public string Name { get; set; }
    }
}